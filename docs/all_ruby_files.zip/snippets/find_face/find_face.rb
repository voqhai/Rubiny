module CURIC::Rubiny
  class FindFaces < Snippet
    def initialize(*args)
      super(*args)
    end
  end
end
