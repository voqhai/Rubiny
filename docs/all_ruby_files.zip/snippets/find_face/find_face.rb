module CURIC::Rubiny
  class FindFace < Snippet
    def initialize(*args)
      super(*args)
    end
  end
end
