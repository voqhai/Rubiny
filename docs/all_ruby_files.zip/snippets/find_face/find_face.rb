module CURIC::Rubiny
  module FindFaces

  end
end
