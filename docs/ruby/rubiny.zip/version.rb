module CURIC::Rubiny

end
