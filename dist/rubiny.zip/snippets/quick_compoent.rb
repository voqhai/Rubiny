module CURIC::Rubiny
  module QuickComponent
    def self.create
      UI.messagebox('Quick Component')
    end
  end
end
